/** @type {import('next-sitemap').IConfig} */
module.exports = {
  siteUrl: 'https://certificadoedigital.com.br/',
  generateRobotsTxt: true,
  sitemapSize: 5000,
};
