import styles from './styles.module.css'

export default function Hero() {
  return (
    <section className={styles.hero}>
      <div className={styles.container}>

        
      <div className={styles.content}>
        <h1 className={styles.titleH1}>
          ADQUIRA O CERTIFICADO <br /> QUE CABE NO <span>SEU BOLSO</span>
        </h1>
        <p className={styles.p}>
          Na Giza Cert, você compra o certificado digital e garante <br />
          sua assinatura eletrônica de um jeito fácil e seguro!
        </p>
        <button className={styles.btt}>Comece agora</button>
      </div>

      <div className={styles.imageWrapper}>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/hero.png" alt="Homem com tablet" className={styles.image} />
      </div>
      </div>
    </section>
  )
}
