import React from 'react'
import styles from './styles.module.css'
import BoxPrice from './BoxPrice'

export default function PriceCertificate() {
    const dataBoxPrice=[
        {
            name:'e-CPF A1',
            price:159
        },
                {
            name:'e-CNPJ A1',
            price:189
        },
                {
            name:'e-CPF A3',
            price:310
        },
        {
            name:'e-CNPJ A3',
            price:330
        },
        
    ]
  return (
    <section className={styles.sectionMain} id='VALORES'>
        <h2>Certificado digital com um dos <br/>
        <span> melhores preços do mercado </span></h2>
        <div className={styles.divBoxs}>
        {dataBoxPrice.map(item=>(
            <BoxPrice name={item.name} price={item.price} key={item.price}/>
        ))}
        </div>
    </section>
  )
}
