import React from "react";
import styles from "./styles.module.css";
import Divider from '@mui/material/Divider';
import FolderOpenIcon from "@mui/icons-material/FolderOpen";
import AccessTimeIcon from "@mui/icons-material/AccessTime";

import Link from "next/link";

interface BoxPriceProps {
  name: string;
  price: number;
}


export default function BoxPrice({ name, price }: BoxPriceProps) {
  const CnpjOrCpf = name.includes("CPF") ? true : false;
  const pcOrToken = name.includes('A3')

  return (
    <div className={styles.divMain}>
      <h3 className={styles.title}>{name}</h3>
      <Divider sx={{width:'100%'}} />
      <p className={styles.subTitle}>
        {CnpjOrCpf ? "Para pessoa física" : "Para empresas"}
      </p>
      <div className={styles.feature}>
        <FolderOpenIcon style={{ color: "#4B0082" }} />
        <p className={styles.text}>Armazenado no {pcOrToken?'Token':'computador'}</p>
      </div>
      <div className={styles.feature}>
        <AccessTimeIcon style={{ color: "#4B0082" }} />
        <p className={styles.text}>Válido por 1 ano</p>
      </div>
      <h5 className={styles.price}>
        R$<span>{price}</span>,00
      </h5>
      <Link target="_blank" href={`https://wa.me/5512991988280?text=Olá%2C%20vi%20o%20certificado%20${name}%20no%20site%20e%20quero%20saber%20como%20posso%20adquirir.
`}>
        <button className={styles.button}>Comprar</button>
      </Link>
    </div>
  );
}
